# JFT-Basic Simulation Android

Project Android untuk simulator JFT-Basic offline. Soal, gambar, dan PDF berada di `app/src/main/assets/www`.

## Build APK langsung dari HP menggunakan GitHub Actions

1. Download ZIP project ini.
2. Di HP, buka GitHub dan buat repository baru, misalnya `jft-basic-simulation`.
3. Extract ZIP, lalu upload **isi folder `JFTBasicAndroidProject`** ke repository tersebut.
4. Pastikan folder `.github/workflows/build-apk.yml` ikut ter-upload. Jika folder tersembunyi tidak terlihat saat upload, buat file tersebut di GitHub dengan isi yang ada di project ini.
5. Buka tab **Actions** di repository.
6. Pilih **Build JFT-Basic APK**.
7. Tekan **Run workflow**.
8. Tunggu sampai status menjadi hijau/Success.
9. Buka hasil workflow dan bagian **Artifacts**.
10. Download **JFT-Basic-Simulation-APK.zip**, extract, lalu install `app-debug.apk` di HP.

Jika GitHub meminta izin untuk menjalankan workflow, setujui/aktifkan Actions untuk repository tersebut.

## Build dengan Android Studio

Buka project ini di Android Studio lalu pilih **Build > Build APK(s)**. APK debug berada di `app/build/outputs/apk/debug/app-debug.apk`.


Build via GitHub Actions workflow in the repository.
